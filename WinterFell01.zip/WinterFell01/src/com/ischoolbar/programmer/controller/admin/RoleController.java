package com.ischoolbar.programmer.controller.admin;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
 
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.ischoolbar.programmer.entity.admin.Authority;
import com.ischoolbar.programmer.entity.admin.Menu;
import com.ischoolbar.programmer.entity.admin.Role;
import com.ischoolbar.programmer.page.admin.Page;
import com.ischoolbar.programmer.service.admin.AuthorityService;
import com.ischoolbar.programmer.service.admin.MenuService;
import com.ischoolbar.programmer.service.admin.RoleService;

/*
  *  角色管理控制器
 * @author lss
 */

@RequestMapping(value="/admin/role")
@Controller
public class RoleController {
     
	@Autowired
	RoleService roleService;
	
	@Autowired
	MenuService menuService;
	@Autowired
	AuthorityService authorityService;
	
	/*
	 * 获取角色列表 页面， GET
	 */
	@RequestMapping(value="/list",method=RequestMethod.GET)
	public ModelAndView list(ModelAndView model) {
		model.setViewName("/role/list");
		return model;
	}
	
	/*
	 * 获取角色列表数据，POST
	 */
	@RequestMapping(value="/list",method=RequestMethod.POST)
	@ResponseBody
	public Map<String, Object> getRoleList(Page page,
		  @RequestParam(name="name",required=false,defaultValue="") String name){
		Map<String,Object> ret = new HashMap<String,Object>();
		Map<String,Object> queryData = new HashMap<String,Object>();
		queryData.put("offset", page.getOffset());
		queryData.put("pageSize", page.getRows());
		queryData.put("name", name);
		
		List<Role> roleList = roleService.findList(queryData);
		ret.put("rows", roleList);
		ret.put("total", roleService.getTotal(queryData));
		return ret;
	}
	
	/*
	 * 新增数据校验 add()
	 */
	@RequestMapping(value="/add",method=RequestMethod.POST)
	@ResponseBody
	public Map<String, String> add(Role role){
		Map<String, String> resultMap = new HashMap<String,String>();
		
		//1.首先校验前台数据集是否为空
		if(role == null) {
			resultMap.put("type", "error");
			resultMap.put("msg", "请填写正确的角色信息");
			return resultMap;
		}
		//2.其次校验每一项输入的合法性
		if(StringUtils.isEmpty(role.getId())) {
			resultMap.put("type", "error");
			resultMap.put("msg", "请填写正确的角色ID信息");
			return resultMap;
		}
		
		if(StringUtils.isEmpty(role.getName())) {
			resultMap.put("type", "error");
			resultMap.put("msg", "请填写正确的角色名称信息");
			return resultMap;
		}
		if(StringUtils.isEmpty(role.getRemark())) {
			resultMap.put("type", "error");
			resultMap.put("msg", "请填写正确的角色描述信息");
			return resultMap;
		}
		if(roleService.add(role) <= 0) {
			resultMap.put("type", "error");
			resultMap.put("msg", "角色信息添加失败，请稍后再试，或者联系管理员");
			return resultMap;
		}
		
		//所有校验通过，并且数据添加成功后
		resultMap.put("type", "success");
		 
		return resultMap;
	}
	
	/*
	 * 修改数据 edit()
	 */
	@RequestMapping(value="/edit",method=RequestMethod.POST)
	@ResponseBody
	public Map<String, String> edit(Role role){
		Map<String, String> resultMap = new HashMap<String,String>();
		
		//1.首先校验前台数据集是否为空
		if(role == null) {
			resultMap.put("type", "error");
			resultMap.put("msg", "请填写正确的角色信息");
			return resultMap;
		}
		//2.其次校验每一项输入的合法性
		if(StringUtils.isEmpty(role.getId())) {
			resultMap.put("type", "error");
			resultMap.put("msg", "请填写正确的角色ID信息");
			return resultMap;
		}
		
		if(StringUtils.isEmpty(role.getName())) {
			resultMap.put("type", "error");
			resultMap.put("msg", "请填写正确的角色名称信息");
			return resultMap;
		}
		if(StringUtils.isEmpty(role.getRemark())) {
			resultMap.put("type", "error");
			resultMap.put("msg", "请填写正确的角色描述信息");
			return resultMap;
		}
		if(roleService.edit(role) <= 0) {
			resultMap.put("type", "error");
			resultMap.put("msg", "角色信息修改失败，请稍后再试，或者联系管理员");
			return resultMap;
		}
		
		//所有校验通过，并且数据添加成功后
		resultMap.put("type", "success");
		return resultMap;
	}
	
	/*
	 *  删除数据 delete()
	 */
	@RequestMapping(value="/delete",method=RequestMethod.POST)
	@ResponseBody
	public Map<String, String> delete(
			@RequestParam(name="id",required=true) Long id){
		Map<String, String> resultMap = new HashMap<String,String>();
		
		//1.首先校验前台数据集是否为空
		if(id == null) {
			resultMap.put("type", "error");
			resultMap.put("msg", "请选择要删除的数据");
			return resultMap;
		}
		//2.校验成功后，执行删除操作
		if(roleService.delete(id) <= 0) {
			resultMap.put("type", "error");
			resultMap.put("msg", "删除失败，请稍后再试，或者联系管理员");
			return resultMap;
		}
		
		//所有校验通过，并且数据添加成功后
		resultMap.put("type", "success");
		resultMap.put("msg", "角色删除成功！");
		return resultMap;
	}
	
	/*
	  *  获取所有的菜单信息
	 * 
	*/
	@RequestMapping(value="/get_all_menu",method=RequestMethod.POST)
	@ResponseBody
	public List<Menu> getAllMenu(){
		Map<String, Object> queryMap = new HashMap<String,Object>();
		queryMap.put("offset", 0);
		queryMap.put("pageSize", 9999);
		return menuService.findList(queryMap);
	}
	
	/*
	 * 
	 * 获得某个角色的所有权限信息
	 */
	@RequestMapping(value="/get_role_authority",method=RequestMethod.POST)
	@ResponseBody
	public List<Authority> getRoleAuthority(
			@RequestParam(name="roleId",required=true) Long roleId){
		return authorityService.findListByRoleId(roleId);
		
	}
	
	
	/*
	 * 添加权限
	 * @param ids
	 * @return Map
	 * 
	 */
	@RequestMapping(value="/add_authority",method=RequestMethod.POST)
	@ResponseBody
	public Map<String, String> addAuthority(
			@RequestParam(name="ids",required=true) String ids,
			@RequestParam(name="roleId",required=true) Long  roleId
			){
		Map<String, String> results = new HashMap<String,String>();
		if(StringUtils.isEmpty(ids)) {
			results.put("type","error");
			results.put("msg", "请选择相应的权限");
			return results;
		}
		if(roleId == null) {
			results.put("type","error");
			results.put("msg", "请选择相应的角色");
			return results;
		}
		//说明请求参数中有多个id
		if(ids.contains(",")) {
			ids = ids.substring(0, ids.length()-1);
		}
		String[] idList = ids.split(",");
		//若数组长度大于0，则删除该角色；为什么？不破不立？避免数据库冲突？
		if(idList.length > 0) {
			authorityService.deleteByRoleId(roleId);
		}
		
		for(String id: idList) {
			Authority authority  = new Authority();
			authority.setMenuId(Long.valueOf(id));
			authority.setRoleId(roleId);
			authorityService.add(authority);
		}
		results.put("type","success");
		results.put("msg", "权限编辑程功");
		 
		return results;
	}	
}
