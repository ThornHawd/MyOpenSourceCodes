package com.Servleter.study;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

 
@WebServlet(
		description = "The demo used to get the information about the header.", 
		urlPatterns = { 
				"/RequestDemo1", 
				"/demo1"
		}, 
		initParams = { 
				@WebInitParam(name = "name", value = "RequestDemo1")
		})
public class RequestDemo1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public RequestDemo1() {
        super();
        // TODO Auto-generated constructor stub
    }
    
	//get the data from client. 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
   		
		
		//1.get the string URL
		String reqUrl= request.getRequestURL().toString();
		//2.get the URI 
		String reqUri = request.getRequestURI();
		//3.get the queryString 
		String queryString = request.getQueryString();
		//4.get the remote address
		String remoteAddr = request.getRemoteAddr();
		//5.get the remote host 
		String remoteHost = request.getRemoteHost();
		//6. the port number
		 int remotePort = request.getRemotePort();
		 //7.remote user
		String  remoteUser  = request.getRemoteUser();
		//8.method type:get or post and etc  ?
		String method = request.getMethod();
		String pathInfo = request.getPathInfo();
		String localAddr = request.getLocalAddr();
		String localName = request.getLocalName();
		
		response.setHeader("content-type", "text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.write("获取到的客户及信息如下：" + "<br/>");
		out.write("请求的URL地址是：" + reqUrl);
		out.write("<br/>");
		out.write("客户请求的资源名称是："+ reqUri);
		out.write("<br/>");
		out.write("请求的URL地址中附带的参数"+queryString);
		out.write("<br/>");
		out.write("来访者的IP地址：" + remoteAddr);
		out.write("<br/>");
		out.write("来访者的主机名："+ remoteHost);
		out.write("<br/>");
		out.write("客户机通讯端口号：" + remotePort);
		out.write("<br/>");
		out.write("使用的请求方法是："+method);
		out.write("<br/>");
		out.write("remote user :"+ remoteUser);
		out.write("<br/>");
		out.write("pathInfo :" + pathInfo);
		out.write("<br/>");
		out.write("localAddr : " + localAddr);
		out.write("<br/>");
		out.write("localName : " + localName);
		
		response.getWriter().write("<br/>");
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
