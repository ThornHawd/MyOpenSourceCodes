package com.Servleter.study;

import java.awt.event.ItemEvent;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
 
@WebServlet(
		description = "The HttpRequestServlet is to get the header of the client request.", 
		urlPatterns = { 
				"/RequestDemo2", 
				"/demo2"
		}, 
		initParams = { 
				@WebInitParam(name = "name", value = "RequestDemo2")
		})
public class RequestDemo2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public RequestDemo2() {
        super();
        // TODO Auto-generated constructor stub
    }

	 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setHeader("content-type", "text/html;charset=UTF-8");
		//response.setCharacterEncoding("UTF-8");
		PrintWriter out = response.getWriter();
		Enumeration <String> reqHeaderInfo = request.getHeaderNames();
		out.write("获取到的客户端所有的请求头信息如下：");
		out.write("<br/>");
		while(reqHeaderInfo.hasMoreElements()) {
			String headName = (String)reqHeaderInfo.nextElement();
			String headValue = request.getHeader(headName);
			out.write("HeadName : " + headValue);
			out.write("<br/>");
		}
		out.write("<br/>");
		out.write("获取到的客户端Accept-Encoding 请求头的值是：");
		out.write("<hr/>");
		String value =request.getHeader("Accept-Encoding");
		out.write(value);
		
		Enumeration<String> headers  = request.getHeaders("Accept-Encoding");
		while(headers.hasMoreElements()) {
			String  item = (String)headers.nextElement();
			System.out.println("Header :" + item);
		}
		response.getWriter().append("Served at: ").append(request.getContextPath());
		out.write("<br/>");
		response.getWriter().write("Hello Thrown" );
	}

	 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
