package com.ischoolbar.programmer.dao.admin;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.ischoolbar.programmer.entity.admin.Authority;

@Repository
public interface AuthorityDao {
	public int add(Authority authority);
    public int deleteByRoleId(long roleId);
    public List<Authority> findListByRoleId(long roleId); 
}
