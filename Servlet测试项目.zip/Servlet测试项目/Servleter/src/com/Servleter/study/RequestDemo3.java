package com.Servleter.study;

import java.io.IOException;
import java.text.MessageFormat;
import java.util.Map;

import javax.annotation.processing.Messager;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.catalina.tribes.group.interceptors.TwoPhaseCommitInterceptor.MapEntry;

 

 
@WebServlet(
		description = "The Servlet is for getting the submitted data from the client .", 
		urlPatterns = { 
				"/RequestDemo3", 
				"/demo3"
		}, 
		initParams = { 
				@WebInitParam(name = "name", value = "RequestDemo3", description = "The demo is to test the data from the client")
		})
public class RequestDemo3 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
     
    public RequestDemo3() {
        super();
        // TODO Auto-generated constructor stub
    }

	 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String userId = request.getParameter("userid");
		String userName = request.getParameter("username");
		String userPassword  = request.getParameter("password");
		String sex = request.getParameter("sex");
		String deparment = request.getParameter("dept");
		String[]intrests = request.getParameterValues("interest");
		String note = request.getParameter("note");
		String hiddenField = request.getParameter("hiddenField");
		String instrestStr = "";
		
		for(int i=0;intrests!=null && i<intrests.length;i++) {
			if(i == intrests.length-1) {
				instrestStr+=intrests[i];
			}
			else {
				instrestStr+=intrests[i]+",";
			}
		}
		
		String htmlStr = "<table>" + 
						"<tr><td>The NO :</td><td>{0}</td></tr>"+
						"<tr><td>The User Name:</td><td>{1}</td></tr>"+
						"<tr><td>Password:</td><td>{2}</td></tr>"+
						"<tr><td>Sex:</td><td>{3}</td></tr>"+
						"<tr><td>Department:</td><td>{4}</td></tr>"+
						"<tr><td>Intrests:</td><td>{5}</td></tr>"+
						"<tr><td>Something:</td><td>{6}</td></tr>"+
						"<tr><td>Hidden field:</td><td>{7}</td></tr>"+
						"</table>";
		htmlStr = MessageFormat.format(htmlStr, userId,userName,userPassword,
				sex,deparment,instrestStr,note,hiddenField);
		
		response.setCharacterEncoding("UTF-8");
		response.setHeader("content-type","text/html;charset=UTF-8");
		response.getWriter().write(htmlStr);
		response.getWriter().write("<br/>");
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		Map<String, String[]> paramsMap = request.getParameterMap();
		for(Map.Entry<String,String[]> entry :paramsMap.entrySet()) {
			String paramName = entry.getKey();
			String paramValue = "";
			String[]paramValues = entry.getValue();
			for(int i=0;paramValues!= null && i<paramValues.length;i++) {
				if(i == paramValues.length) {
					paramValue+=paramValues[i];
				}else {
					paramValue+=paramValues[i]+",";
				}
			}
			
			System.out.println(MessageFormat.format("{0} == {1}", paramName,paramValues));
		}
	}

	 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
