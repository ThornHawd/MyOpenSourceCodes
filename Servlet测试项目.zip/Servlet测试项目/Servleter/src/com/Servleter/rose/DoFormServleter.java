package com.Servleter.rose;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

 
@WebServlet(
		description = "The Servleter is mainly used to prevent the form to be submitted twice or more.", 
		urlPatterns = { 
				"/DoFormServleter", 
				"/d3"
		}, 
		initParams = { 
				@WebInitParam(name = "name", value = "DoServleter")
		})
public class DoFormServleter extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public DoFormServleter() {
        super();
        // TODO Auto-generated constructor stub
    }

	 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setCharacterEncoding("UTF-8");
		String userName = request.getParameter("userName");
		try {
			Thread.sleep(3*1000);
		}catch(InterruptedException e) {
		  e.printStackTrace();
		}
		System.out.println("Insert  the data to the madKIng."+userName);
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}
 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
