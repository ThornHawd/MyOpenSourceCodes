package com.Servleter.study;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(
		description = "The Servlet is used to test the HTTP Header.", 
		urlPatterns = { 
				"/RequestServlet", 
				"/test1"
		}, 
		initParams = { 
				@WebInitParam(name = "Name", value = "HttpRequestServlet")
		})
public class RequestServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public RequestServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setHeader("content-type", "text/html;charset=UTF-8");
		response.getWriter().append("Served at: ").append(request.getContextPath());
		response.getWriter().write("<br/>");
		
		response.getWriter().write("hello world. Hugs each other:"+ "刘赛赛 ");
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
