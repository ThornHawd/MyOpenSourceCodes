package com.ischoolbar.programmer.controller.admin;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import java.util.List;
import com.ischoolbar.programmer.entity.admin.Menu;
import com.ischoolbar.programmer.page.admin.Page;
import com.ischoolbar.programmer.service.admin.MenuService;


/*
 *  菜单管理控制器
 */
@RequestMapping("/admin/menu")
@Controller
public class MenuController {
	
	@Autowired
	private MenuService menuService;
	/*
	 * 显示菜单列表 页面
	 */
	@RequestMapping(value="/list",method=RequestMethod.GET)
	public ModelAndView list(ModelAndView model) {
		model.addObject("topList",menuService.findTopList());
		model.setViewName("menu/list");
		return model;
	}
	
	/*
	 * 显示系统设置/菜单列表 表格
	 */
	@RequestMapping(value="/list",method=RequestMethod.POST)
	@ResponseBody
	public Map<String,Object> getMenuList(Page page,
		@RequestParam(name="name",required=false,defaultValue="")	String name) {
		 Map<String,Object> data = new HashMap<String,Object>();
		 Map<String,Object> result = new HashMap<String,Object>();
		 data.put("pageSize", page.getRows());
		 data.put("offset", page.getOffset());
		 data.put("name", name);
		 List<Menu> menuList = menuService.findList(data);
		 result.put("rows", menuList);
		 result.put("total", menuService.getTotal(data));
		 return result;
	}
	
	@RequestMapping(value="/get_icons",method=RequestMethod.POST)
	@ResponseBody
	public Map<String,Object> getIconList(HttpServletRequest request) {
		
		//存储返回结果集，result
		 Map<String,Object> result = new HashMap<String,Object>();
		//拿到项目所在的绝对路径，默认是WebContent的磁盘路径
		 String WebPath = request.getServletContext().getRealPath("/");
		 //创建一个文件对象
		 File file = new File(WebPath + "\\resources\\admin\\easyui\\css\\icons");
		 if(!file.exists()) {
			 result.put("type", "error");
			 result.put("msg", "文件路径无效，请求出错");
			 return result;
		 }
		 
		 //当文件路径没问题时，开始遍历图标文件
		 //icons 图标文件名称数组
		 List<String> icons = new ArrayList<String>();
		 File[] fileList  = file.listFiles();
		 for(File f : fileList ) {
			 if(f != null && f.getName().contains("png")) {
				 icons.add("icon-"+ f.getName().substring(0, f.getName().indexOf(".")).replace('_', '-'));
			 }
		 }
		 result.put("type", "success");
		 result.put("content", icons);
		 
		 return result;
	}
	
	/*
	 * 新增菜单
	 */
	@RequestMapping(value="/add",method=RequestMethod.POST)
	@ResponseBody
	public Map<String,String>  add(Menu model) {
		 Map<String, String> data = new HashMap<String,String>();
		 //进行一般的数据校验，建议是将该方法封装到一个Util工具类里
		 if(model == null) {
			 data.put("type", "error");
			 data.put("msg", "传递来的数据为空，请检查您的数据输入.");
			 return data;
		 }
		 if(StringUtils.isEmpty(model.getName())) {
			 data.put("type", "error");
			 data.put("msg", "Error! 请检查菜单名称");
			 return data;
		 }
		 if(StringUtils.isEmpty(model.getIcon())) {
			 data.put("type", "error");
			 data.put("msg", "Error! 请检查图标选项");
			 return data;
		 }
		 if(StringUtils.isEmpty(model.getParentId())) {
			  model.setParentId(1);
		 }
		 
		 //校验之后，向数据库添加数据
		 if(menuService.add(model) <= 0) {
			 data.put("type", "error");
			 data.put("msg", "Error!请联系管理员反馈此问题");
			 return data;
		 }
		//校验通过
		 data.put("type", "success");
		 data.put("msg", "添加成功,践行铁的意志");
		return data;
	}
	 
	/*
	 * 编辑一个菜单选项
	 */
	@RequestMapping(value="/edit",method=RequestMethod.POST)
	@ResponseBody
	public Map<String,String>  edit(Menu model) {
		 Map<String, String> data = new HashMap<String,String>();
		 //进行一般的数据校验，建议是将该方法封装到一个Util工具类里
		 if(model == null) {
			 data.put("type", "error");
			 data.put("msg", "传递来的数据为空，请检查您的数据输入.");
			 return data;
		 }
		 if(StringUtils.isEmpty(model.getName())) {
			 data.put("type", "error");
			 data.put("msg", "Error! 请检查菜单名称");
			 return data;
		 }
		 if(StringUtils.isEmpty(model.getIcon())) {
			 data.put("type", "error");
			 data.put("msg", "Error! 请检查图标选项");
			 return data;
		 }
		 if(StringUtils.isEmpty(model.getParentId())) {
			  model.setParentId(1);
		 }
		 
		 //校验之后，向数据库添加数据
		 if(menuService.edit(model) <= 0) {
			 data.put("type", "error");
			 data.put("msg", "Error!请联系管理员反馈此问题");
			 return data;
		 }
		 data.put("type", "success");
		 data.put("msg", "编辑成功！");
		return data;
	}
	
	@RequestMapping(value="/delete",method=RequestMethod.POST)
	@ResponseBody
	public Map<String, String> delete(
			@RequestParam(name="id",required=true) Long id){
		Map<String, String> ret = new HashMap<String,String>();
		if(id == null){
			ret.put("type", "error");
			ret.put("msg", "请选择要删除的菜单信息!");
			return ret;
		}
		List<Menu> findChildernList = menuService.findChildrenList(id);
		if(findChildernList != null && findChildernList.size() > 0){
			//表示该分类下存在子分类，不能删除
			ret.put("type", "error");
			ret.put("msg", "该分类下存在子分类，不能删除!");
			return ret;
		}
		if(menuService.delete(id) <= 0){
			ret.put("type", "error");
			ret.put("msg", "删除失败，请联系管理员!");
			return ret;
		}
		
		ret.put("type", "success");
		ret.put("msg", "删除成功");
		return ret;
	}
}
