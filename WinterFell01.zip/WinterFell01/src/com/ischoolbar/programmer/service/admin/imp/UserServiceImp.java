package com.ischoolbar.programmer.service.admin.imp;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ischoolbar.programmer.dao.admin.UserDao;
import com.ischoolbar.programmer.entity.admin.User;
 
import com.ischoolbar.programmer.service.admin.UserService;

/*
 * UserService
 */
@Service
public class UserServiceImp implements UserService {
  
	@Autowired
	private UserDao userDao;
	
	@Override
	public User getByUsername(String username) {
        return userDao.getByUsername(username);
	}
	@Override
	public int add(User user) {
		 
		return userDao.add(user);
	}
	@Override
	public int delete(String ids) {
		 return userDao.delete(ids);
	}
	@Override
	public int update(User user) {
		return userDao.update(user);
	}
	@Override
	public int edit(User user) {
		 return userDao.edit(user);
	}
	@Override
	public List<User> findList(Map<String, Object> queryData) {
		return userDao.findList(queryData);
	}
	public int getTotal(Map<String, Object> queryMap) {
		return userDao.getTotal(queryMap);
	}

}
