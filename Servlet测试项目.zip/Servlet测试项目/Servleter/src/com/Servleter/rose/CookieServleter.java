package com.Servleter.rose;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.concurrent.CountDownLatch;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

 

@WebServlet(
		description = "The Servleter is mainly for testing the cookie and session", 
		urlPatterns = { 
				"/CookieServleter", 
				"/d1"
		}, 
		initParams = { 
				@WebInitParam(name = "name", value = "CookieServleter")
		})
public class CookieServleter extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public CookieServleter() {
        super();
        //  
    }
 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//1.set the response header 
		response.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		//2.get a stream io
		PrintWriter out = response.getWriter();
		//3.get a cookie array from the request.
		Cookie[] cookies = request.getCookies();
	    //
		if(cookies != null) {
			out.write("The last accessing time is : ");
			for(int i=0,count=cookies.length;i<count;i++) {
				Cookie cookie = cookies[i];
				if(cookie.getName().equals("lastAccessTime")) {
					long lastAccessTime = Long.parseLong(cookie.getValue());
					Date date = new Date(lastAccessTime);
					
					out.write(date.toString());
				}
			}
		}else{
			out.write("This is the first time you visited the web site.<br/>");
			
		}
		//Add a static field named of lastAccessTime to Cookie object.
		Cookie cookie = new Cookie("lastAccessTime", System.currentTimeMillis()+"");
		cookie.setMaxAge(60);
		response.addCookie(cookie);
		 
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//  
		doGet(request, response);
	}

}
