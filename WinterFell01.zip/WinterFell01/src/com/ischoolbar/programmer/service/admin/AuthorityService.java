package com.ischoolbar.programmer.service.admin;

import java.util.List;

import org.springframework.stereotype.Service;

import com.ischoolbar.programmer.entity.admin.Authority;

@Service
public interface AuthorityService {
    public int add(Authority authority);
    public int deleteByRoleId(long roleId);
    public List<Authority> findListByRoleId(long roleId); 
}
