package com.ischoolbar.programmer.entity.admin;

import org.springframework.stereotype.Component;

@Component
public class User {
    private Long id;
    private String username;
    private Long roleId;//用户角色Id
  
	private String password;
    private String photo;
    private int sex;
    private int age;
    private String address;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getPhoto() {
		return photo;
	}
	public void setPhoto(String photo) {
		this.photo = photo;
	}
	public int getSex() {
		return sex;
	}
	public void setSex(int sex) {
		this.sex = sex;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
    
    public Long getRoleId() {
			return roleId;
		}
    public void setRoleId(Long roleId) {
			this.roleId = roleId;
		}
}
