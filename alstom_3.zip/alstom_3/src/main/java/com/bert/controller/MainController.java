package com.bert.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.HashMap;
import java.util.Map;

/*
    接收用户数据
 */
@Controller
@RequestMapping(value="/main")
public class MainController {
    /*
        测试POST请求
     */
    @RequestMapping(value="/post",method= RequestMethod.POST)
    public String index(String username,String password){

        System.out.println(username + password);
        return "success";
    }

    /*
        接收工业数据,返回JSON数据包到页面
     */
   @RequestMapping("/collect")
   @ResponseBody
    public Map<String,Object> show( ){
        Map<String,Object> map = new HashMap<String,Object>();


        return map;
    }
}
