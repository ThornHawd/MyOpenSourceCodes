package com.bert.chaper2.reflect;

public class ReflectServiceImp {
    public void sayHello(String name) {
    	System.out.println("Hello ,I am not a coder " + name + "\n");
    	System.err.println("Hello" + name);
    }
	
}
