package com.bert.springboot.controller;

 

import java.util.Arrays;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
 
import org.springframework.web.bind.annotation.ResponseBody;

 
@Controller
public class HelloController {
	    
	  
	    @ResponseBody
	    @RequestMapping(value= {"/hello"})
	    public String hello(){
	        return "<h1> Hello World Quick Start.</h1>" +"<h3>" + "刘赛赛的实验室" + "<h3/>";
	    }
	    
	    @RequestMapping(value="/success")
	    public String show(Map<String,Object> map) {
	    	map.put("hello", "Liu Sai Sai");
	    	map.put("userList", Arrays.asList("Jack","Laura","Edward"));
	    	return "success";
	    	
	    }
	    
	    
}
