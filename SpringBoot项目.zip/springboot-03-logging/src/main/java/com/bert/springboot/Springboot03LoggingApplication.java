package com.bert.springboot;

 
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springboot03LoggingApplication {
  
	
	
	public static void main(String[] args) {
		SpringApplication.run(Springboot03LoggingApplication.class, args);
		
		
		
		System.out.println("欢迎来到刘赛赛创建的实验室");
		System.out.println("本次实验主要内容是   测试 Springboot 日志框架");
	}

}
