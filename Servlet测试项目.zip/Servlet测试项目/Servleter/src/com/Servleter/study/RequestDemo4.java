package com.Servleter.study;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

 

@WebServlet(
		description = "The demo is to test the request forward.", 
		urlPatterns = { 
				"/RequestDemo4", 
				"/demo4"
		}, 
		initParams = { 
				@WebInitParam(name = "name", value = "RequestDemo4")
		})
public class RequestDemo4 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public RequestDemo4() {
        super();
        // TODO Auto-generated constructor stub
    }
 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//RequestDispatcher requestDispatcher = this.getServletContext().getRequestDispatcher("/WhiteWalkings.jsp");
		RequestDispatcher requestDispatcher = request.getRequestDispatcher("/WhiteWalkings.jsp");
		requestDispatcher.forward(request, response);
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
