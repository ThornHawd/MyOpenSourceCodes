package com.ischoolbar.programmer.service.admin;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.ischoolbar.programmer.entity.admin.User;
 

@Service
public interface UserService {
       public User getByUsername(String username);
       public int add(User user) ;
       public int delete(String ids);
       public int update(User user);
       public int edit(User user);
       
       public List<User> findList(Map<String,Object> queryMap);
       public int getTotal(Map<String, Object> queryMap);
       
}
