package com.ischoolbar.programmer.interceptor.admin;

 
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

 
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.ischoolbar.programmer.entity.admin.User;

import net.sf.json.JSONObject;

 
/**
 * 后台登录拦截器
 * @author lss
 *
 */
public class LoginInterceptor implements HandlerInterceptor {

	@Override
	public void afterCompletion(HttpServletRequest request,
			HttpServletResponse response, Object obj, Exception e)
			throws Exception {
		 User adminInfo = (User)request.getSession().getAttribute("admin");
		 String username = adminInfo.getUsername();
		 System.out.println("当前系统时间是：" + new Date().toString());
		 System.out.println("Your request has been completed successfully...."+"尊敬的 " + username);
		 System.out.println("----------*******---------");
		 

	}

	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response,
			Object obj, ModelAndView model) throws Exception {
		 User adminInfo = (User)request.getSession().getAttribute("admin");
		 String username = adminInfo.getUsername();
		 System.out.println("Nin 的请求正在被处理中...."+"尊敬的 " + username);
		 

	}

	/*
	 * 用户登录校验，登录前
	 * @see org.springframework.web.servlet.HandlerInterceptor#preHandle(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse, java.lang.Object)
	 */
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object obj) throws Exception {
		
		//1.首先拿到session中保存的用户登录信息 client_user;
		Object client_user = request.getSession().getAttribute("admin");
		//2.客户端登录信息为null,则表示登录超时或者未登录状态
		if(client_user == null) {
			// headerInfo:客户端AJAX请求字符串
			String headerInfo = request.getHeader("X-Requested-With");
			if("XMLHTTPRequest".equals(headerInfo)) {
				//如果是Ajax请求，则返回一个消息包 data 到向应流response
				Map<String, String> data = new HashMap();
				data.put("type","error" );
				data.put("msg", "用户未登录或者登录超时，请重新登陆");
				response.getWriter().write(JSONObject.fromObject(data).toString());	
				return false;
			}
			//如果是普通的请求，就直接跳转到登录页面;
			//路径拼接 request.getServletContext().getContextPath(); 获得网站根目录 
			response.sendRedirect(request.getServletContext().getContextPath() + "/system/login");
			String URIName =  request.getRequestURI();
			System.out.println("被访问的资源名称是："+ URIName);
			System.out.println("您的登陆请求正在被处理，请稍候...");
			return false;
		}
		//表示用户已经登录，返回为true
		String URIName =  request.getRequestURI();
		System.out.println("被访问的资源名称是："+ URIName);
		return true;
	}

 

}
