package com.bert;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Alstom3Application {

    public static void main(String[] args) {
        SpringApplication.run(Alstom3Application.class, args);
    }

}
