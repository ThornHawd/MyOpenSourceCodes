package com.bert.chaper2.reflector;

import com.bert.chaper2.reflect.*;
public class Reflector {
   @SuppressWarnings("deprecation")
public ReflectServiceImp getServiceNonArgs() {
	   
	    ReflectServiceImp object = null;
	    try {
	    	object =(ReflectServiceImp) Class.forName("com.bert.chapter2.reflect.ReflectServiceImp").
	    			newInstance();
	    }catch(ClassNotFoundException  |  InstantiationException  | IllegalAccessException e) {
	    	e.printStackTrace();
	    }
	    
	    return object;
	    
   }

	
}
