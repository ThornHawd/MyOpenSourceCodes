package com.ischoolbar.programmer.page.admin;

import org.springframework.stereotype.Component;
/*
 * @pageNum 当前页码
 * @rows  每页显示数据条数
 * @offset 对应数据库中的偏移量
 */
@Component
public class Page {
   private int pageNum =1; 
   private int rows ;
   private int offset;
   
public int getPageNum() {
	return pageNum;
}
public void setPageNum(int pageNum) {
	this.pageNum = pageNum;
}
public int getRows() {
	return rows;
}
public void setRows(int rows) {
	this.rows = rows;
}
public int getOffset() {
	return offset;
}
public void setOffset(int offset) {
	this.offset =( pageNum - 1)* rows;
	 
}
   
   
}
