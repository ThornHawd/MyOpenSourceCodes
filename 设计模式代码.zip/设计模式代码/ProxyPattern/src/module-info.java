/**
 * 
 */
/**
 * @author Bert
 *
 */
module ProxyPattern {
	exports Reflector;
}