
import com.bert.chaper2.reflector.Reflector;

public class Main {
  
	 public static void main(String []args) {
		  Reflector reflector = new Reflector();
		   reflector.getServiceNonArgs().sayHello("Jack Joes");
		 System.out.println("\n It happened to anynoe of us. \n  "
		 		+ "she means noting to me.");
		 
	 }
}
