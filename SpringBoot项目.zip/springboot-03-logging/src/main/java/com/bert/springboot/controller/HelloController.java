package com.bert.springboot.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {
     
	 Logger logger = LoggerFactory.getLogger(getClass());

	 @RequestMapping(value= {"/hello","/"})
    public String sayHello(){
		 
		 logger.trace("这是trace 级别的日志");
		 logger.debug("这是 Debug 级别的日志");
		 logger.info("这是Info 级别的日志");
		 logger.warn("这是 Warn 级别的日志");
		 logger.error("这是 Error 级别的日志");
        return "Hello World！ "; 
    }
}
